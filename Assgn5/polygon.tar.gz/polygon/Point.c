/*
 * Author: <Your Name>
 * A point (Implementation)
 */

#include "Point.h"

