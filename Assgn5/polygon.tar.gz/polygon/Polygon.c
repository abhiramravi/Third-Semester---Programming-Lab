/*
 * Author: <Your Name>
 * Polygon (Implementation)
 */

#include "CLinkedList.h"
#include "Polygon.h"

