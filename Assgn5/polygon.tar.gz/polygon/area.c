/*
 * Author: <Your Name>
 * Compute the area of a polygon
 */

#include "Polygon.h"

int main( int argc, char* argv[] )
{


    return 0;
}

