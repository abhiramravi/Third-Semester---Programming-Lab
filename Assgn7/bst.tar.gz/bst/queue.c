/*
 * Author: Abhiram R - CS10B060
 * qUEUE data structure (Implementation)
 */

#include "queue.h"
#include "LList.h"
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

queue* queue_new()
{
    queue* new_queue;
    new_queue = malloc(20*sizeof(qNode));
    new_queue->top = NULL;
    new_queue->bottom = NULL;
    return new_queue;
}
void queue_delete( queue* q)
{
    while(q->top!=NULL)
    {
        queue_pop(q);        
    }
}
queue* enqueue( queue* q, int val )
{
    qNode *x;
    x=malloc(sizeof(qNode));
    x->data = val;
    x->next = q->bottom;
    q->bottom = x;
    if(q->top == NULL) q->top = x;
}
queue* dequeue( queue* q )
{
    if(q->top == NULL)
    {
        printf("Empty queue\n");
        return q;
    }
    else
    {
        free(q->top);
        q->top = (q->top)->next;
        return q;
    }
}
void queue_print( queue* q )
{
    qNode* ptr;
    int i=0,j=0;
    char* string;
    string = malloc(100*sizeof(char));
    ptr = q->top;
    while(ptr!=NULL)
    {
        //printf("%d ",ptr->data);       
        string[i] = ptr->data;
        i++;
        ptr = ptr->next;
    }
    for(j=i-1;j>=0;j--)
    {
        printf("%d ", string[j]);
    }
    printf("\n");
   
}
