/*
 * Author: Abhiram R - CS10B060
 * Queue data structure
 */
#include"LList.h"
#ifndef QUEUE_H
#define QUEUE_H

typedef struct queue_ {
    qNode* top;
    qNode* bottom;
} queue;

// Create a new empty queue
queue* queue_new();
// Deletes the queue, frees memory.
void queue_delete( queue* q );

// Inserts @val to the bottom of the queue
queue* enqueue( queue* q, int val );
// Remove the element at the top of the queue - also frees memory
queue* dequeue( queue* q );

// Returns the element currently at the top of the stack. If the stack is empty,
// @error should be set to 1, else 0.
int queue_top( queue* st, int* error );
int queue_size( queue* st );
void queue_print( queue* st );

#endif // QUEUE_H

