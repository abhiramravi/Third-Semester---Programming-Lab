#ifndef CAPITALIZE_H
#define CAPITALIZE_H

#include <string.h>

#define MAX_CHARS 500
void capitalize_string( char *str );

#endif
