/*
 * Name (Rollno)
 * Insertion sort
 */

#ifndef INSERTION_SORT_H
#define INSERTION_SORT_H

// Sort
void insertion_sort( int n, int* arr );

#endif // INSERTION_SORT_H
