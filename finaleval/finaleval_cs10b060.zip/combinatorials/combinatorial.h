#ifndef COMBINATORIALS_H
#define COMBINATORIALS_H

unsigned long int factorial( unsigned long int, unsigned long int *store);
unsigned long int n_C_k( unsigned long int c, unsigned long int k, unsigned long int *factorial_store);

#endif
