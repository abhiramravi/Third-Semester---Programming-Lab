/*
 * Abhiram CS10B060
 * Mergesort
 */

#ifndef MERGESORT_H
#define MERGESORT_H

// Sort
void mergesort( int n, int* arr );
void msort(int* a, int p, int r);
void merge(int* a, int p, int q, int r);

#endif // TOKENISER_H
