/*
 * Name (Rollno)
 * Insertion sort
 */

#ifndef QSORT_H
#define QSORT_H

// Sort
void QSort( int n, int* arr );

#endif // QSORT_H
