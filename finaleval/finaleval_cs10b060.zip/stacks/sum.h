#ifndef SUM_H
#define SUM_H
#include <string.h>

int sum_numeric_ascii( char *str);
int check_and_eliminate_occurrences(int n, char *str, char ch);

#endif
